'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.ConfigCtrl = undefined;

var _config = require('./components/config');

exports.ConfigCtrl = _config.ZabbixAppConfigCtrl;
