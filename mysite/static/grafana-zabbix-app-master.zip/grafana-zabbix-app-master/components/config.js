'use strict';

System.register([], function (_export, _context) {
  var ZabbixAppConfigCtrl;

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  return {
    setters: [],
    execute: function () {
      _export('ZabbixAppConfigCtrl', ZabbixAppConfigCtrl = function ZabbixAppConfigCtrl() {
        _classCallCheck(this, ZabbixAppConfigCtrl);
      });

      _export('ZabbixAppConfigCtrl', ZabbixAppConfigCtrl);

      ZabbixAppConfigCtrl.templateUrl = 'components/config.html';
    }
  };
});
//# sourceMappingURL=config.js.map
